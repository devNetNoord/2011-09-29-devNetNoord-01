﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using devNetNoord.Demo.Entities;
using devNetNoord.Demo.Data;
using devNetNoord.Demo.Business;
using devNetNoord.Demo.UI.Web.Models;

namespace devNetNoord.Demo.UI.Web.Controllers
{ 
    public class CustomerController : Controller
    {
        private ICustomerManager customerManager;

        public CustomerController()
        {
            ICustomerRepository customerRepository = new CustomerRepository();
            this.customerManager = new CustomerManager(customerRepository);
        }

       //
        // GET: /Customer/

        public ViewResult Index()
        {
             return View(this.customerManager.GetCustomers()); 
        }

        //
        // GET: /Customer/Edit/5
 
        public ActionResult Edit(int id)
        {
            Territory[] territories = this.customerManager.GetTerritories();
            Customer customer = this.customerManager.GetCustomer(id);

            CustomerViewModel model = new CustomerViewModel()
            {
                CustomerID = customer.CustomerID,
                PersonID = customer.PersonID,
                StoreID = customer.StoreID,
                TerritoryID = customer.TerritoryID,
                AccountNumber = customer.AccountNumber,

                Territories = (from t in territories select new SelectListItem() { Value = t.TerritoryID.ToString(), Text = t.Name }).ToArray()
            };

            return View(model);
        }

        //
        // POST: /Customer/Edit/5

        [HttpPost]
        public ActionResult Edit(Customer customer)
        {
            if (ModelState.IsValid)
            {
                this.customerManager.UpdateCustomer(customer);

                return RedirectToAction("Index");
            }
            return View(customer);
        }

        public JsonResult CheckPersonID(int? personID)
        {
            if (personID.HasValue && personID > 100)
            {
                return Json(true, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json("Ongeldige personID", JsonRequestBehavior.AllowGet);
            }
        }
    }
}