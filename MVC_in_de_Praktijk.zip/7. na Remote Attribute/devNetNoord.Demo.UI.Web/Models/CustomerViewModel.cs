﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace devNetNoord.Demo.UI.Web.Models
{
    public class CustomerViewModel
    {
        public int CustomerID { get; set; }
        [Remote("CheckPersonID", "Customer")]
        public int? PersonID { get; set; }
        public int? StoreID { get; set; }
        public int? TerritoryID { get; set; }
        public string AccountNumber { get; set; }

        public SelectListItem[] Territories { get; set; }
    }
}