﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using devNetNoord.Demo.Entities;

namespace devNetNoord.Demo.Business
{
    public interface ICustomerManager
    {
        Customer[] GetCustomers();

        Territory[] GetTerritories();

        Customer GetCustomer(int customerID);

        void UpdateCustomer(Customer customer);
    }
}
