﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using devNetNoord.Demo.Data;
using devNetNoord.Demo.Entities;

namespace devNetNoord.Demo.Business
{
    public class CustomerManager : ICustomerManager
    {
        private ICustomerRepository customerRepository;

        public CustomerManager(ICustomerRepository customerRepository)
        {
            this.customerRepository = customerRepository;
        }

        public Customer[] GetCustomers()
        {
            int[] territories = { 2, 3 };

            return this.customerRepository.GetCustomers(territories);
        }

        public Territory[] GetTerritories()
        {
            return this.customerRepository.GetTerritories();
        }

        public Customer GetCustomer(int customerID)
        {
            return this.customerRepository.GetCustomer(customerID);
        }

        public void UpdateCustomer(Customer customer)
        {
            this.customerRepository.UpdateCustomer(customer);
        }
    }
}
