﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using devNetNoord.Demo.Entities;

namespace devNetNoord.Demo.Data
{
    public interface ICustomerRepository
    {
        Customer[] GetCustomers(params int[] territories);

        Territory[] GetTerritories();

        Customer GetCustomer(int customerID);

        void UpdateCustomer(Customer customer);
  
    }
}
