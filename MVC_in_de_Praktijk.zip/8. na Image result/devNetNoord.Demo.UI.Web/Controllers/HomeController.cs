﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace devNetNoord.Demo.UI.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Message = "Welcome to ASP.NET MVC!";

            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public FilePathResult Image()
        {
            string filePath = System.IO.Path.Combine((string)AppDomain.CurrentDomain.GetData("DataDirectory"), "devNetNoord-W-410.png");

            return File(filePath, "image/png");
        }
    }
}
