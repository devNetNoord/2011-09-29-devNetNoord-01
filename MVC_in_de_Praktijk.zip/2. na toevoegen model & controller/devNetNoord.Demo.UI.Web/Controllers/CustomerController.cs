﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using devNetNoord.Demo.UI.Web.Models;

namespace devNetNoord.Demo.UI.Web.Controllers
{ 
    public class CustomerController : Controller
    {
        private AdventureWorksContext db = new AdventureWorksContext();

        //
        // GET: /Customer/

        public ViewResult Index()
        {
            return View(db.Customers.Where(c => c.TerritoryID == 2 || c.TerritoryID == 3).ToList());
        }
        
        //
        // GET: /Customer/Edit/5
 
        public ActionResult Edit(int id)
        {
            Customer customer = db.Customers.Find(id);
            return View(customer);
        }

        //
        // POST: /Customer/Edit/5

        [HttpPost]
        public ActionResult Edit(Customer customer)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(customer);
        }
    }
}