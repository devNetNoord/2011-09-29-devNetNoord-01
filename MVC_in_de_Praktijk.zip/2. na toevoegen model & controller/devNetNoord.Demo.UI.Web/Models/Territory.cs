﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace devNetNoord.Demo.UI.Web.Models
{
    public class Territory
    {
        public int TerritoryID { get; set; }
        public string Name { get; set; }
    }
}