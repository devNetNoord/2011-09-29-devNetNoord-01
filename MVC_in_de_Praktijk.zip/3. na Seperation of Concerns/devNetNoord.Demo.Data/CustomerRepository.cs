﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using devNetNoord.Demo.Entities;
using System.Data;

namespace devNetNoord.Demo.Data
{
    public class CustomerRepository
    {
        public Customer[] GetCustomers(params int[] territories)
        {
            using (AdventureWorksContext db = new AdventureWorksContext())
            {
                return db.Customers.Where(c => c.TerritoryID.HasValue && territories.Contains(c.TerritoryID.Value)).ToArray();
            }
        }

        public Territory[] GetTerritories()
        {
            using (AdventureWorksContext db = new AdventureWorksContext())
            {
                return db.Territories.ToArray();
            }
        }

        public Customer GetCustomer(int customerID)
        {
            using (AdventureWorksContext db = new AdventureWorksContext())
            {
                return db.Customers.Find(customerID);
            }
        }

        public void UpdateCustomer(Customer customer)
        {
            using (AdventureWorksContext db = new AdventureWorksContext())
            {
                db.Entry(customer).State = EntityState.Modified;
                db.SaveChanges();
            }
        }
    }
}
