﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using devNetNoord.Demo.Data;
using devNetNoord.Demo.Entities;

namespace devNetNoord.Demo.Business
{
    public class CustomerManager
    {
        private CustomerRepository customerRepository;

        public CustomerManager()
        {
            this.customerRepository = new CustomerRepository();
        }

        public CustomerManager(CustomerRepository customerRepository)
        {
            this.customerRepository = customerRepository;
        }

        public Customer[] GetCustomers()
        {
            int[] territories = { 2, 3 };

            return this.customerRepository.GetCustomers(territories);
        }

        public Territory[] GetTerritories()
        {
            return this.customerRepository.GetTerritories();
        }

        public Customer GetCustomer(int customerID)
        {
            return this.customerRepository.GetCustomer(customerID);
        }

        public void UpdateCustomer(Customer customer)
        {
            this.customerRepository.UpdateCustomer(customer);
        }
    }
}
