﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using devNetNoord.Demo.Entities;
using devNetNoord.Demo.Data;
using devNetNoord.Demo.Business;
using devNetNoord.Demo.UI.Web.Models;

namespace devNetNoord.Demo.UI.Web.Controllers
{ 
    public class CustomerController : Controller
    {
        private ICustomerManager customerManager;

        public CustomerController()
        {
            ICustomerRepository customerRepository = new CustomerRepository();
            this.customerManager = new CustomerManager(customerRepository);
        }

       //
        // GET: /Customer/

        public ViewResult Index()
        {
             return View(this.customerManager.GetCustomers()); 
        }

        //
        // GET: /Customer/Edit/5
 
        public ActionResult Edit(int id)
        {
            return View(this.customerManager.GetCustomer(id));
        }

        //
        // POST: /Customer/Edit/5

        [HttpPost]
        public ActionResult Edit(Customer customer)
        {
            if (ModelState.IsValid)
            {
                this.customerManager.UpdateCustomer(customer);

                return RedirectToAction("Index");
            }
            return View(customer);
        }
    }
}